function sendMessage(event, socket) {
	event.preventDefault();

	let channel = document.getElementById('channel').value;
	let message = document.getElementById('message').value;
	let username = document.getElementById('username').value;
	
	
	let chatContainer = document.getElementById('chatContainer');
	let chatMessage = document.createElement('div');
	chatMessage.className = 'col-12';
	chatMessage.innerHTML = `
	<div class="card sent-message">
		<div class="card-body">
			<h5 class="card-title">${channel}</h5>
			<p class="card-text">Me : ${message}</p>
		</div>
	</div>`;
	chatContainer.insertBefore(chatMessage, chatContainer.firstChild);

	if (!document.getElementById('channelsList').innerHTML.includes(channel))
		socket.emit('joinChannel', { channel });
	
	socket.emit('message', { username, channel, message });

}

function joinChannel(event, socket) {
	event.preventDefault();
	let channel = document.getElementById('newchannel').value;
	if (channel && channel != '')
		socket.emit('joinChannel', { channel });
}

function leaveChannel(event, socket) {
	event.preventDefault();
	let channel = document.getElementById('newchannel').value;
	if (channel && channel != '')
		socket.emit('leaveChannel', { channel });
}

function onWelcomeMessageReceived(msg) {
	let chatContainer = document.getElementById('chatContainer');
	let chatMessage = document.createElement('div');
	chatMessage.className = 'col-12';
	chatMessage.innerHTML = `
	<div class="card received-message">
		<div class="card-body">
			<p class="card-text">System : ${msg}</p>
		</div>
	</div>`;
	chatContainer.appendChild(chatMessage);
}

function onNewMessageReceived(newMessage) {
	if (newMessage) {
		let chatContainer = document.getElementById('chatContainer');
		let chatMessage = document.createElement('div');
		chatMessage.className = 'col-12';
		chatMessage.innerHTML = `
		<div class="card received-message">
			<div class="card-body">
				<h5 class="card-title">${newMessage.channel}</h5>
				<p class="card-text"> ${newMessage.username} : ${newMessage.message}</p>
			</div>
		</div>`;
		chatContainer.insertBefore(chatMessage, chatContainer.firstChild);
	}
}

function onAddedToNewChannelReceived(newChannel) {
	if (newChannel) {
		let alertContainer = document.getElementById("alertContainer");
		let alertMsg = document.createElement('div');
		alertMsg.className = 'alert alert-success alert-dismissible fade show';
		alertMsg.innerHTML = `
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			You are added to <strong>${newChannel.channel}</strong> successfully!
		`;
		alertContainer.appendChild(alertMsg);

		let channnelList = document.getElementById('channelsList');
		if (!channnelList.innerHTML.includes(newChannel.channel)) {
			let option = document.createElement('option');
			option.innerHTML = newChannel.channel;
			channnelList.appendChild(option);
		}
	}
}

function onRemovedFromChannelReceived(removedChannel) {
	if (removedChannel) {
		let alertContainer = document.getElementById("alertContainer");
		let alertMsg = document.createElement('div');
		alertMsg.className = 'alert alert-success alert-dismissible fade show';
		alertMsg.innerHTML = `
			<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
			You are removed from <strong>${removedChannel.channel}</strong> successfully!
		`;
		alertContainer.appendChild(alertMsg);
	}
}

module.exports = {
	sendMessage,
	joinChannel,
	leaveChannel,
	onWelcomeMessageReceived,
	onNewMessageReceived,
	onAddedToNewChannelReceived,
	onRemovedFromChannelReceived
};

// You will get error - Uncaught ReferenceError: module is not defined
// while running this script on browser which you shall ignore
// as this is required for testing purposes and shall not hinder
// it's normal execution

