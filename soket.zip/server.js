function bootstrapSocketServer(io) {
	io.on('connection', (socket) => {
		socket.on('register', (regObj) => {

			socket.emit('welcomeMessage', `Welcome ${regObj.username} !!`);
			if (Array.isArray(regObj.channels)) {
				regObj.channels.forEach(channel => {
					socket.join(channel);
					socket.emit('addedToChannel', { 
						channel: channel 
					});
				});
			}

			socket.on('joinChannel', (channelObj) => {
				if (channelObj) {
					socket.join(channelObj.channel);
					socket.emit('addedToChannel', { 
						channel: channelObj.channel 
					});
				}
			});
	
			socket.on('leaveChannel', (channelObj) => {
				if (channelObj) {
					socket.leave(channelObj.channel);
					socket.emit('removedFromChannel', { 
						channel: channelObj.channel
					});
				}
			});

		});

		socket.on('message', (chatObj) => {
			if (chatObj) {
				socket.to(chatObj.channel).emit('newMessage', { 
						message: chatObj.message, 
						username: chatObj.username,
						channel: chatObj.channel
					});
			}
		});
	});
}

module.exports = bootstrapSocketServer;
