import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ContactsComponent } from './contacts/contacts.component';
import { ContactsListComponent } from './contacts-list/contacts-list.component';
import { ContactsGridComponent } from './contacts-grid/contacts-grid.component';

const routes: Routes = [
  {path: '', component: DashboardComponent, pathMatch: 'full'},
  {path:'contacts',component:ContactsComponent,
    children:[
      {path: '', redirectTo:'list', pathMatch: 'full'},
      {path: 'list', component: ContactsListComponent},
      {path: 'grid', component: ContactsGridComponent}
  ]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
