import { Component, OnInit } from '@angular/core';
import { Contact } from '../models/contact';
import { ContactService } from '../services/contact.service';

@Component({
  selector: 'app-contacts-list',
  templateUrl: './contacts-list.component.html',
  styleUrls: ['./contacts-list.component.css']
})
export class ContactsListComponent implements OnInit {

  listContact: Contact[];
  constructor(private Csss:ContactService) { 
    this.listContact = [];
  }

  ngOnInit() {
    this.Csss.getContacts().subscribe(
      (data) => {
        this.listContact = data;
      }
    );
  }

}
