export class Contact {
    cid: number
    firstName: string
    lastName: string
    mobile: string
    mail: string
    dateOfBirth: Date
    gender: string
    group: string
}
